import React, { useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useBrokerConnect } from '../context/BrokerConnectContext';
import { Mail, Building2, ShieldCheck, ArrowRight, UserPlus, CheckCircle, Smartphone, KeyRound, ChevronLeft, Users, BarChart3 } from 'lucide-react';
import { PinCode } from 'rizzui/pin-code';

export const Login: React.FC = () => {
  const { setCurrentRole, setActiveScreen } = useBrokerConnect();
  const navigate = useNavigate();
  const location = useLocation();

  // Route state notifications (like registration success redirects)
  const redirectSuccess = location.state?.success as string || '';

  // Form States
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [otpStep, setOtpStep] = useState(false); // Toggle Step 1 vs Step 2
  const [pin, setPin] = useState('');
  const [pinKey, setPinKey] = useState(0);

  const [loginError, setLoginError] = useState('');
  const [loginSuccess, setLoginSuccess] = useState(redirectSuccess);
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    if (otpStep) {
      setTimeout(() => {
        const firstInput = document.querySelector('.rizzui-pin-code-root input') as HTMLInputElement;
        firstInput?.focus();
      }, 150);
    }
  }, [otpStep, pinKey]);

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrPhone) {
      setLoginError('Please enter your Email or Phone');
      return;
    }
    setLoginError('');
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      setOtpStep(true);
      alert(`Simulation: SMS/Email OTP code '1234' sent to ${emailOrPhone}`);
    }, 600);
  };

  const handleLoginSubmit = (e?: React.FormEvent, codeOverride?: string) => {
    if (e) e.preventDefault();
    const finalCode = codeOverride || pin;
    if (!finalCode || finalCode.length < 4) {
      setLoginError('Please enter the 4-digit OTP code');
      return;
    }
    if (finalCode !== '1234') {
      setLoginError('Invalid OTP code. Please enter 1234 to verify.');
      return;
    }

    setLoading(true);
    setLoginError('');

    setTimeout(() => {
      setLoading(false);
      const userLower = emailOrPhone.toLowerCase();
      if (userLower.includes('admin')) {
        setCurrentRole('admin');
        setActiveScreen(14);
      } else if (userLower.includes('reception') || userLower.includes('desk')) {
        setCurrentRole('receptionist');
        setActiveScreen(6);
      } else if (userLower.includes('sales') || userLower.includes('exec')) {
        setCurrentRole('sales');
        setActiveScreen(9);
      } else {
        setCurrentRole('broker');
        setActiveScreen(2);
      }
      navigate('/dashboard');
    }, 800);
  };

  const handlePinChange = (val: string) => {
    setPin(val);
    if (val.length === 4) {
      if (val === '1234') {
        handleLoginSubmit(undefined, val);
      } else {
        setLoginError('Invalid OTP code. Please enter 1234 to verify.');
      }
    } else {
      setLoginError('');
    }
  };

  const handleBackToEmail = () => {
    setOtpStep(false);
    setPin('');
    setPinKey(prev => prev + 1);
    setLoginError('');
  };

  const triggerQuickShortcut = (value: string) => {
    setEmailOrPhone(value);
    setOtpStep(false);
    setPin('');
    setPinKey(prev => prev + 1);
    setLoginError('');
  };
  return (
    <div className="flex min-h-screen flex-col lg:flex-row bg-slate-50/50 text-slate-800 text-left font-sans">
      {/* Mobile Branding Header */}
      <div className="flex lg:hidden w-full bg-[#0d284a] py-4 px-6 items-center justify-center border-b border-blue-950/80 shadow-md">
        <img 
          src="/logo.png" 
          alt="Logo" 
          className="h-8.5 w-auto object-contain" 
        />
      </div>

      {/* Left side: Premium Branding (Desktop Only) */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-[#0d284a] via-[#0f2942] to-[#0b1b30] text-white p-16 flex-col justify-between relative overflow-hidden border-r border-blue-950/40">
        {/* Background grid lines */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:24px_24px] z-0"></div>
        
        {/* White curved arc/wave sweeps matching mockup exactly */}
        <div className="absolute top-[-15%] right-[-15%] w-[650px] h-[650px] rounded-full border-2 border-white/20 bg-gradient-to-tr from-white/5 to-transparent pointer-events-none z-0"></div>
        <div className="absolute top-[-25%] right-[-25%] w-[850px] h-[850px] rounded-full border-2 border-white/10 pointer-events-none z-0"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[320px] h-[320px] rounded-full bg-white/5 pointer-events-none z-0"></div>
 
        <div className="relative z-20 self-start hover:opacity-90 transition-opacity">
          <img 
            src="/logo.png" 
            alt="Logo" 
            className="h-8.5 w-auto object-contain" 
          />
        </div>
 
        {/* Branding text directly on background */}
        <div className="relative z-10 space-y-6 flex flex-col">
          <span className="self-start px-3.5 py-1.5 bg-blue-900/40 text-blue-350 text-[10px] font-extrabold rounded-full border border-blue-800/60 uppercase tracking-widest">
            Channel Partner Protection
          </span>
          <div className="space-y-4">
            <h1 className="text-3xl xl:text-4xl font-extrabold tracking-tight leading-[1.2] text-white">
              Lead Protection &amp; Sales Management
            </h1>
            <div className="w-12 h-1 bg-blue-500 rounded-full"></div>
          </div>
          <p className="text-xs text-blue-200/90 font-semibold leading-relaxed">
            Eliminating channel partner disputes through instant OTP-based customer ownership locks and transparent audit trails.
          </p>
        </div>
 
        {/* Features list below the card */}
        <div className="relative z-10 flex flex-col gap-4">
          <div className="flex items-center gap-4 text-xs font-semibold text-blue-250">
            <div className="w-12 h-12 rounded-2xl bg-blue-900/50 border border-blue-850/50 flex items-center justify-center text-blue-400 shrink-0 shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="space-y-0.5">
              <span className="text-sm font-bold text-white block">Secure OTP-based lead locking</span>
              <span className="text-[10px] text-blue-300/70 font-semibold block">Locks active for 60 seconds</span>
            </div>
          </div>
          <div className="flex items-center gap-4 text-xs font-semibold text-blue-250">
            <div className="w-12 h-12 rounded-2xl bg-blue-900/50 border border-blue-850/50 flex items-center justify-center text-blue-400 shrink-0 shadow-xs">
              <Users className="w-5 h-5" />
            </div>
            <div className="space-y-0.5">
              <span className="text-sm font-bold text-white block">Automated round-robin allocation</span>
              <span className="text-[10px] text-blue-300/70 font-semibold block">Fair &amp; intelligent lead distribution</span>
            </div>
          </div>
          <p className="text-[10px] text-blue-400/80 mt-4 font-bold tracking-wide">
            © 2026 BrokerConnect Technologies. All rights reserved.
          </p>
        </div>
      </div>
 
      {/* Right side: Forms Canvas */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 md:p-16 bg-slate-50/50">
        <div className="w-full max-w-[460px] bg-white border border-slate-100/80 rounded-[32px] p-8 sm:p-10 shadow-xl shadow-slate-100/40 space-y-8 animate-in fade-in zoom-in-95 duration-200">
 
          <div className="space-y-6">
            <div className="space-y-2">
              <h2 className="text-3xl font-extrabold tracking-tight text-slate-900">
                Welcome Back
              </h2>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                {otpStep ? 'Verify your identity' : 'Login to access your partner dashboard & leads'}
              </p>
            </div>

            {loginSuccess && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-600 rounded-xl text-xs font-bold flex items-center gap-2 animate-bounce">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>{loginSuccess}</span>
              </div>
            )}

            {loginError && (
              <div className="p-3.5 bg-red-50 border border-red-200 text-red-600 rounded-xl text-xs font-semibold">
                {loginError}
              </div>
            )}

            {/* STEP 1: ENTER EMAIL OR PHONE */}
            {!otpStep ? (
              <form onSubmit={handleSendOtp} className="space-y-5">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">
                    Email or Phone *
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <Mail className="w-4.5 h-4.5" />
                    </span>
                    <input
                      type="text"
                      placeholder="Enter registered email or phone number"
                      value={emailOrPhone}
                      onChange={(e) => setEmailOrPhone(e.target.value)}
                      className="block w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-800 font-semibold shadow-xs transition"
                      required
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs font-semibold text-slate-600">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span>Remember Me</span>
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex justify-center items-center gap-2 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-450 text-white rounded-xl font-bold text-xs transition-all shadow-md shadow-blue-500/10 cursor-pointer"
                >
                  {loading ? (
                    <div className="w-4.5 h-4.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span>Send OTP Code</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            ) : (
              /* STEP 2: VERIFY OTP CODE */
              <form onSubmit={(e) => handleLoginSubmit(e)} className="space-y-5 animate-in fade-in slide-in-from-right-4 duration-200">
                <div className="space-y-2.5">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">
                      OTP Security PIN *
                    </label>
                    <button
                      type="button"
                      onClick={handleBackToEmail}
                      className="flex items-center gap-1 text-[10px] font-bold text-blue-600 hover:underline transition"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                      <span>Change Email/Phone</span>
                    </button>
                  </div>

                  {/* RizzUI PinCode Component */}
                  <div className="py-2.5">
                    <PinCode
                      key={pinKey}
                      length={4}
                      setValue={handlePinChange as any}
                      size="lg"
                      placeholder="o"
                      center={true}
                      inputClassName="!w-14 !h-14 text-center text-xl font-extrabold !bg-slate-50 !border !border-slate-200 !rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-blue-600 focus:bg-white text-slate-800 transition-all duration-150 !shadow-sm !mr-2 placeholder:!text-slate-300 placeholder:!font-normal"
                    />
                  </div>
                </div>

                <div className="text-xs text-slate-400 font-semibold">
                  OTP simulated sent to <strong className="text-slate-700">{emailOrPhone}</strong>. Key in <strong className="text-blue-600">1234</strong> to login.
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex justify-center items-center gap-2 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-450 text-white rounded-xl font-bold text-xs transition-all shadow-md shadow-blue-500/10 cursor-pointer"
                >
                  {loading ? (
                    <div className="w-4.5 h-4.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span>Verify &amp; Login</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* Redirection to register */}
            <div className="pt-4 border-t border-slate-100 flex justify-between items-center text-xs font-semibold text-slate-500">
              <span>New channel partner?</span>
              <Link
                to="/register"
                className="flex items-center gap-1.5 text-blue-600 hover:text-blue-700 transition font-bold"
              >
                <UserPlus className="w-4 h-4" />
                <span>Register as Broker</span>
              </Link>
            </div>

            {/* Quick Access Grid Panel */}
            <div className="mt-8 pt-6 border-t border-slate-100 space-y-3">
              <span className="text-[10px] font-bold text-slate-400 block text-center uppercase tracking-widest">
                Quick Access
              </span>
              <div className="grid grid-cols-2 gap-3 text-xs font-medium">
                <button
                  onClick={() => triggerQuickShortcut('98765 43210')}
                  className="flex items-center gap-3 p-3 bg-white hover:bg-blue-50/50 border border-slate-150 rounded-2xl text-left transition cursor-pointer shadow-xs active:scale-[0.98]"
                >
                  <div className="p-2 bg-blue-50/70 text-blue-600 rounded-xl shrink-0">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-extrabold text-slate-800 block">Broker</span>
                    <span className="text-[10px] text-slate-400 font-semibold block mt-0.5">(Amit Patel)</span>
                  </div>
                </button>
                <button
                  onClick={() => triggerQuickShortcut('reception')}
                  className="flex items-center gap-3 p-3 bg-white hover:bg-blue-50/50 border border-slate-150 rounded-2xl text-left transition cursor-pointer shadow-xs active:scale-[0.98]"
                >
                  <div className="p-2 bg-blue-50/70 text-blue-600 rounded-xl shrink-0">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-extrabold text-slate-800 block">Receptionist</span>
                    <span className="text-[10px] text-slate-400 font-semibold block mt-0.5">Portal</span>
                  </div>
                </button>
                <button
                  onClick={() => triggerQuickShortcut('sales')}
                  className="flex items-center gap-3 p-3 bg-white hover:bg-blue-50/50 border border-slate-150 rounded-2xl text-left transition cursor-pointer shadow-xs active:scale-[0.98]"
                >
                  <div className="p-2 bg-blue-50/70 text-blue-600 rounded-xl shrink-0">
                    <BarChart3 className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-extrabold text-slate-800 block">Sales CRM</span>
                    <span className="text-[10px] text-slate-400 font-semibold block mt-0.5">View</span>
                  </div>
                </button>
                <button
                  onClick={() => triggerQuickShortcut('admin')}
                  className="flex items-center gap-3 p-3 bg-white hover:bg-blue-50/50 border border-slate-150 rounded-2xl text-left transition cursor-pointer shadow-xs active:scale-[0.98]"
                >
                  <div className="p-2 bg-blue-50/70 text-blue-600 rounded-xl shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-extrabold text-slate-800 block">Admin Panel</span>
                    <span className="text-[10px] text-slate-400 font-semibold block mt-0.5">(Disputes)</span>
                  </div>
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Login;
